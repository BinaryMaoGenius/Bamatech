// Gestion optimisée du chargement avec gestion d'erreurs
document.addEventListener('DOMContentLoaded', function() {
    try {
        // Suppression du loader
        const loader = document.querySelector('.loader');
        if (loader) {
            loader.style.opacity = '0';
            loader.style.visibility = 'hidden';
            setTimeout(() => {
                if (loader.parentNode) {
                    loader.parentNode.removeChild(loader);
                }
            }, 300);
        }

        // Initialisation des composants
        const components = [
            initCarousel,
            setupDarkMode,
            setupMobileMenu,
            setupChat,
            setupNotifications,
            setupContactForm,
            setupScrollEffects
        ];

        // Initialisation séquentielle avec gestion d'erreurs
        components.forEach(component => {
            try {
                component();
            } catch (error) {
                console.error(`Erreur dans l'initialisation de ${component.name}:`, error);
            }
        });

    } catch (error) {
        console.error('Erreur lors du chargement de la page:', error);
    }
});

// Carrousel optimisé avec gestion mémoire
function initCarousel() {
    const carouselInner = document.querySelector('.carousel-inner');
    const slides = document.querySelectorAll('.carousel-item');
    const indicatorsContainer = document.getElementById('carouselIndicators');
    
    if (!slides.length || !carouselInner) return;

    let currentSlide = 0;
    let slideInterval = null;
    let isPaused = false;

    // Initialisation des indicateurs
    if (indicatorsContainer) {
        indicatorsContainer.innerHTML = '';
        slides.forEach((_, index) => {
            const indicator = document.createElement('div');
            indicator.className = 'carousel-indicator';
            if (index === 0) indicator.classList.add('active');
            indicator.addEventListener('click', () => goToSlide(index));
            indicatorsContainer.appendChild(indicator);
        });
    }

    // Navigation - gestion des événements optimisée
    const nextBtn = document.querySelector('.carousel-next');
    const prevBtn = document.querySelector('.carousel-prev');
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            goToSlide(currentSlide + 1);
            resetInterval();
        });
    }
    
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            goToSlide(currentSlide - 1);
            resetInterval();
        });
    }

    function goToSlide(n) {
        currentSlide = (n + slides.length) % slides.length;
        carouselInner.style.transform = `translateX(-${currentSlide * 100}%)`;
        
        // Mise à jour des indicateurs
        document.querySelectorAll('.carousel-indicator').forEach((indicator, index) => {
            indicator.classList.toggle('active', index === currentSlide);
        });
    }

    function startInterval() {
        if (slideInterval) clearInterval(slideInterval);
        if (!isPaused) {
            slideInterval = setInterval(() => goToSlide(currentSlide + 1), 5000);
        }
    }

    function resetInterval() {
        startInterval();
    }

    function pauseInterval() {
        isPaused = true;
        if (slideInterval) {
            clearInterval(slideInterval);
            slideInterval = null;
        }
    }

    function resumeInterval() {
        isPaused = false;
        startInterval();
    }

    // Gestion du survol avec gestion des événements délégués
    const carousel = document.querySelector('.carousel');
    if (carousel) {
        carousel.addEventListener('mouseenter', pauseInterval);
        carousel.addEventListener('mouseleave', resumeInterval);
        carousel.addEventListener('touchstart', pauseInterval, { passive: true });
        carousel.addEventListener('touchend', resumeInterval, { passive: true });
    }

    // Démarrage initial
    startInterval();

    // Nettoyage pour éviter les fuites mémoire
    return () => {
        if (slideInterval) clearInterval(slideInterval);
        if (carousel) {
            carousel.removeEventListener('mouseenter', pauseInterval);
            carousel.removeEventListener('mouseleave', resumeInterval);
            carousel.removeEventListener('touchstart', pauseInterval);
            carousel.removeEventListener('touchend', resumeInterval);
        }
    };
}

// Mode sombre optimisé avec localStorage sécurisé
function setupDarkMode() {
    const darkModeToggle = document.getElementById("dark-mode-toggle");
    if (!darkModeToggle) return;

    const darkModeIcon = darkModeToggle.querySelector('i');
    
    function updateDarkModeIcon() {
        if (darkModeIcon) {
            if (document.body.classList.contains('dark-mode')) {
                darkModeIcon.classList.replace('fa-moon', 'fa-sun');
            } else {
                darkModeIcon.classList.replace('fa-sun', 'fa-moon');
            }
        }
    }

    function toggleDarkMode() {
        const isDarkMode = document.body.classList.toggle('dark-mode');
        try {
            localStorage.setItem('darkMode', isDarkMode);
        } catch (error) {
            console.warn('Impossible d\'accéder au localStorage:', error);
        }
        updateDarkModeIcon();
        
        // Dispatch un événement personnalisé pour les autres composants
        document.dispatchEvent(new CustomEvent('darkModeChanged', { 
            detail: { isDarkMode } 
        }));
    }

    darkModeToggle.addEventListener('click', toggleDarkMode);

    // Application du mode au chargement
    try {
        const savedDarkMode = localStorage.getItem('darkMode');
        if (savedDarkMode === 'true') {
            document.body.classList.add('dark-mode');
        }
    } catch (error) {
        console.warn('Impossible de lire le localStorage:', error);
    }
    
    updateDarkModeIcon();
}

// Menu mobile optimisé avec gestion des événements
function setupMobileMenu() {
    const menuBtn = document.getElementById("menu-btn");
    const sidebar = document.getElementById("sidebar");
    const mainContent = document.querySelector(".main");

    if (!menuBtn || !sidebar) return;

    function toggleMenu() {
        const isOpen = sidebar.style.left === "0px";
        sidebar.style.left = isOpen ? "-260px" : "0px";
        if (mainContent) {
            mainContent.style.marginLeft = isOpen ? "0" : "260px";
        }
        
        // Accessibilité: mise à jour de l'état ARIA
        menuBtn.setAttribute('aria-expanded', !isOpen);
        sidebar.hidden = isOpen;
    }

    function closeMenu(event) {
        if (sidebar.style.left === "0px" && 
            !sidebar.contains(event.target) && 
            event.target !== menuBtn) {
            sidebar.style.left = "-260px";
            if (mainContent) {
                mainContent.style.marginLeft = "0";
            }
            menuBtn.setAttribute('aria-expanded', 'false');
            sidebar.hidden = true;
        }
    }

    menuBtn.addEventListener("click", function(e) {
        e.stopPropagation();
        toggleMenu();
    });

    // Fermeture en cliquant à l'extérieur - avec throttling
    let clickTimeout = null;
    document.addEventListener('click', function(event) {
        if (clickTimeout) clearTimeout(clickTimeout);
        clickTimeout = setTimeout(() => closeMenu(event), 10);
    });

    // Fermeture avec la touche Escape
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && sidebar.style.left === "0px") {
            sidebar.style.left = "-260px";
            if (mainContent) {
                mainContent.style.marginLeft = "0";
            }
            menuBtn.setAttribute('aria-expanded', 'false');
            sidebar.hidden = true;
        }
    });

    // Nettoyage
    return () => {
        document.removeEventListener('click', closeMenu);
        document.removeEventListener('keydown', closeMenu);
        if (clickTimeout) clearTimeout(clickTimeout);
    };
}

// Chat optimisé avec gestion des messages
function setupChat() {
    const chatBtn = document.getElementById("chat-btn");
    const chatBox = document.getElementById("chat-box");
    const closeChat = document.getElementById("close-chat");
    const sendBtn = document.getElementById("send-message-btn");
    const chatInput = document.getElementById("chat-text");

    if (!chatBtn || !chatBox) return;

    const botResponses = [
        "Merci pour votre message. Un conseiller vous répondra sous peu.",
        "Nous avons bien reçu votre demande et la traitons dans les meilleurs délais.",
        "Pour une réponse plus rapide, vous pouvez nous contacter au +223 20 20 20 20.",
        "Nos bureaux sont ouverts du lundi au vendredi de 8h à 17h.",
        "Consultez notre FAQ pour des réponses aux questions fréquentes."
    ];

    function toggleChat() {
        chatBox.classList.toggle('visible');
        if (chatBox.classList.contains('visible') && chatInput) {
            chatInput.focus();
        }
    }

    function closeChatBox() {
        chatBox.classList.remove('visible');
    }

    function sendMessage() {
        if (!chatInput) return;
        
        const message = chatInput.value.trim();
        
        if (message) {
            // Protection XSS
            const safeMessage = message.replace(/</g, "&lt;").replace(/>/g, "&gt;");
            
            addMessage(safeMessage, 'user-message');
            chatInput.value = "";
            
            // Réponse automatique avec délai aléatoire
            setTimeout(() => {
                const response = botResponses[Math.floor(Math.random() * botResponses.length)];
                addMessage(response, 'bot-message');
            }, 800 + Math.random() * 700);
        }
    }

    function addMessage(text, className) {
        const messages = document.getElementById("chat-messages");
        if (!messages) return;
        
        const msg = document.createElement("div");
        msg.className = `message ${className}`;
        msg.textContent = text;
        messages.appendChild(msg);
        messages.scrollTop = messages.scrollHeight;
    }

    // Gestion des événements
    chatBtn.addEventListener("click", function(e) {
        e.stopPropagation();
        toggleChat();
    });

    if (closeChat) {
        closeChat.addEventListener("click", closeChatBox);
    }

    if (sendBtn && chatInput) {
        sendBtn.addEventListener('click', sendMessage);
        chatInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }

    // Fermeture en cliquant à l'extérieur
    document.addEventListener("click", function(event) {
        if (chatBox.classList.contains('visible') && 
            !chatBox.contains(event.target) && 
            event.target !== chatBtn) {
            closeChatBox();
        }
    });

    // Fermeture avec Escape
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && chatBox.classList.contains('visible')) {
            closeChatBox();
        }
    });
}

// Notifications optimisées
function setupNotifications() {
    const closeBtn = document.getElementById("close-notification-btn");
    const notification = document.getElementById("news-notification");

    if (!closeBtn || !notification) return;

    function closeNotification() {
        notification.classList.remove('show');
        try {
            localStorage.setItem('notificationClosed', 'true');
        } catch (error) {
            console.warn('Impossible d\'accéder au localStorage:', error);
        }
    }

    closeBtn.addEventListener('click', closeNotification);

    // Affichage conditionnel
    try {
        if (localStorage.getItem('notificationClosed') !== 'true') {
            setTimeout(() => {
                notification.classList.add('show');
            }, 3000);
        }
    } catch (error) {
        console.warn('Impossible de lire le localStorage:', error);
    }
}

// Formulaire de contact optimisé avec validation
function setupContactForm() {
    const contactForm = document.getElementById("contact-form");
    if (!contactForm) return;

    contactForm.addEventListener("submit", function(e) {
        e.preventDefault();
        
        // Validation basique
        const name = document.getElementById("name");
        const email = document.getElementById("email");
        const subject = document.getElementById("subject");
        const message = document.getElementById("message");
        
        let isValid = true;
        
        if (!name.value.trim()) {
            showFieldError(name, "Le nom est requis");
            isValid = false;
        }
        
        if (!email.value.trim() || !isValidEmail(email.value)) {
            showFieldError(email, "Un email valide est requis");
            isValid = false;
        }
        
        if (!subject.value) {
            showFieldError(subject, "Veuillez sélectionner un sujet");
            isValid = false;
        }
        
        if (!message.value.trim()) {
            showFieldError(message, "Le message ne peut pas être vide");
            isValid = false;
        }
        
        if (!isValid) return;
        
        // Simulation d'envoi réussi
        showNotification("Merci pour votre message! Nous vous contacterons bientôt.");
        contactForm.reset();
        
        // Nettoyage des erreurs
        clearFieldErrors();
    });

    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    function showFieldError(field, message) {
        // Création ou réutilisation du message d'erreur
        let errorElement = field.nextElementSibling;
        if (!errorElement || !errorElement.classList.contains('error-message')) {
            errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            field.parentNode.insertBefore(errorElement, field.nextSibling);
        }
        
        errorElement.textContent = message;
        field.classList.add('error');
    }

    function clearFieldErrors() {
        document.querySelectorAll('.error-message').forEach(el => el.remove());
        document.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
    }
}

// Effets de scroll optimisés avec requestAnimationFrame
function setupScrollEffects() {
    let scrollTimeout = null;
    let lastScrollTop = 0;
    let ticking = false;
    
    // Barre de progression et bouton retour en haut
    function handleScroll() {
        const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = height > 0 ? (winScroll / height) * 100 : 0;
        
        // Barre de progression
        const progressBar = document.getElementById("progressBar");
        if (progressBar) progressBar.style.width = scrolled + "%";
        
        // Bouton retour en haut
        const backToTopBtn = document.getElementById("back-to-top");
        if (backToTopBtn) {
            backToTopBtn.style.display = winScroll > 300 ? "flex" : "none";
        }

        // Animation des éléments au scroll avec RAF
        if (!ticking) {
            requestAnimationFrame(() => {
                animateOnScroll(winScroll);
                ticking = false;
            });
            ticking = true;
        }

        lastScrollTop = winScroll;
    }

    // Utilisation de requestAnimationFrame pour de meilleures performances
    let rafId = null;
    function onScroll() {
        if (rafId) cancelAnimationFrame(rafId);
        rafId = requestAnimationFrame(handleScroll);
    }

    window.addEventListener('scroll', onScroll, { passive: true });

    // Retour en haut
    const backToTopBtn = document.getElementById("back-to-top");
    if (backToTopBtn) {
        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // Animation des éléments avec intersection observer si disponible
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });

        // Observer les éléments à animer
        document.querySelectorAll('section, .card').forEach(el => {
            observer.observe(el);
        });
    } else {
        // Fallback pour les navigateurs sans IntersectionObserver
        function animateOnScroll() {
            const elements = document.querySelectorAll('section, .card');
            const windowHeight = window.innerHeight;
            
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                if (elementPosition < windowHeight - 100) {
                    element.classList.add('fade-in');
                }
            });
        }
        
        // Animation initiale
        animateOnScroll();
    }

    // Nettoyage
    return () => {
        window.removeEventListener('scroll', onScroll);
        if (rafId) cancelAnimationFrame(rafId);
    };
}

// Fonction utilitaire pour les notifications
function showNotification(message, duration = 5000) {
    const notification = document.createElement('div');
    notification.className = 'notification show';
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, duration);
}

// Gestion de la visibilité de la page
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // Page cachée - économiser les ressources
        console.log('Page cachée - optimisation des ressources');
    } else {
        // Page visible - reprendre les animations
        console.log('Page visible - reprise des fonctionnalités');
    }
});

// Gestion du beforeunload pour le nettoyage
window.addEventListener('beforeunload', function() {
    // Nettoyage des ressources si nécessaire
    console.log('Nettoyage avant déchargement de la page');
});